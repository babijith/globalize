<?php

defined('BASEPATH') OR exit('No direct script access allowed');

 function curl_Request($url = NULL,$userData = NULL, $token = NULL){

	$ch = curl_init($url);
			if($token!=NULL){
				$header = array("Authorization: Bearer ".$token);
				curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
			}
			curl_setopt($ch, CURLOPT_TIMEOUT, 30);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
			curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS,$userData);

			$result = curl_exec($ch);
			if (curl_errno($ch)) {
               $result = curl_error($ch);
			}
			curl_close($ch);
			return $result;
}