<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	function __construct() {
        parent::__construct();
        $this->load->helper('core_helper');
    }

	
	public function index()
	{
		$this->load->view('user/login');
	}

	public function login()
	{
        
		if($this->input->post()){
			$userData = array(
			    'username' => $this->input->post('username'),
			    'password' => $this->input->post('password'),
			);
            $url = base_url().'api/login';
			$result = curl_Request($url,$userData,NULL);
				$output = json_decode($result);
				if($output->status !=0){
					$this->session->set_userdata('token',$output->token);
					$this->session->set_userdata('user_id',$output->userid);
				}
			}
			
			echo ($result); exit;
		}

	public function registration()
	{
        if($this->input->post()){
			$userData = array(
			    'username' => $this->input->post('username'),
			    'password' => $this->input->post('password'),
			    'confirm' => $this->input->post('confirm'),
			);

            $url = base_url().'/api/registration';
			$result = curl_Request($url,$userData,NULL);
			echo ($result); exit;
		}
		$this->load->view('user/registration');

	}

	public function event()
	{
		if($this->session->userdata('user_id') ==''){
			redirect('/user');
		}
		$this->load->model('Api_model');
		$uid =$this->session->userdata('user_id');
		if($this->input->post()){
			$eventData = array(
			    'eventname' => $this->input->post('eventname'),
			    'eventdesc' => $this->input->post('eventdesc'),
			    'eventtime' => $this->input->post('eventtime'),
			    'user_id' => $this->session->userdata('user_id')
			);
            $url = base_url().'/api/event';
            $token = $this->session->userdata('token');
	        $ch = curl_init($url);
			$result = curl_Request($url,$eventData,$token);
			echo ($result); exit;
		}
		$data['events'] = $this->Api_model->readEvents($uid);
		$this->load->view('user/event',$data);
	}
	public function logout(){
		$this->session->unset_userdata('token');
		$this->session->unset_userdata('user_id');
		redirect('/user');
	}
}
