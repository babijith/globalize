<?php

require APPPATH.'libraries/REST_Controller.php';
class Api extends REST_Controller{

  public function __construct(){
  
    parent::__construct();
    //load database
    $this->load->database();
    $this->load->library(array("form_validation"));
    $this->load->helper("security");
    $this->load->model('api_model','api');
  }

  public function login_post(){
  	
  	$username = $this->security->xss_clean($this->input->post("username"));
    $password = $this->security->xss_clean($this->input->post("password"));
  	$this->form_validation->set_rules("username", "Username", "required");
  	$this->form_validation->set_rules("password", "Password", "required");
  	if($this->form_validation->run() === FALSE){
	  	$this->response(array(
	        "status" => 0,
	        "message" => "All fields are needed"
	     ) , REST_Controller::HTTP_NOT_FOUND);
  	}else{
        
        $check_valid_user = $this->api->check_user_exists($username, $password);
		if(!empty($check_valid_user)){
            
			$token['id'] = $check_valid_user['id'];
			$token['username'] = $check_valid_user['username'];
			
			$date = new DateTime();
			$token['iat'] = $date->getTimestamp();
			$token['exp'] = $date->getTimestamp() + 60*60*5;
			$this->load->helper("jwt_helper");
			$jwtkey = $this->config->item('thekey');
			$output['token'] = jwt_encode($token,$jwtkey);
			$output['status'] = 1;
			$output['userid'] = $check_valid_user['id'];
			$output['message'] = "Success";			
	        $this->response($output, REST_Controller::HTTP_OK);
	    }else{

	      $this->response(array(
	        "status" => 0,
	        "message" => "Invalid username or password"
	      ), REST_Controller::HTTP_INTERNAL_SERVER_ERROR);
	    }
    }
  }
  public function registration_post(){
		$username = $this->security->xss_clean($this->input->post("username"));
		$password = $this->security->xss_clean($this->input->post("password"));
		$confirm = $this->security->xss_clean($this->input->post("confirm"));
		$this->form_validation->set_rules("username", "Username", "required");
		$this->form_validation->set_rules("password", "Password", "required");
		$this->form_validation->set_rules("confirm", "confirm", "required|matches[password]");
		if($this->form_validation->run() === FALSE){
			$this->response(array(
			"status" => 0,
			"message" => strip_tags(validation_errors())
			) , REST_Controller::HTTP_NOT_FOUND);
		}else{
			$create_datetime= date('Y-m-d H:i:s');
			$key = $this->config->item('encryption_key');
		    $hashed = hash('sha512', $key . $password);
	    	$hashed_password = hash('sha512', $hashed . $password);
			$insert_data =array('username'=>$username,
								'password'=>$hashed_password,
								'created_date'=>$create_datetime);
			$this->db->insert("users", $insert_data);
			$this->response(array(
	        "status" => 1,
	        "message" => "Data inserted"
	      ), REST_Controller::HTTP_OK);
		}

    }


	public function tokenValidate($token){
	    $jwtkey = $this->config->item('thekey');
	    try {
	       $this->load->helper("jwt_helper");
	       $token = str_replace('Bearer ','',$token); 
	       $decoded = jwt_decode($token, $jwtkey, array('HS256'));
	       $result = (array) $decoded;
	       $result['status'] = 'success';
	    } catch (Exception $e) {
	        $result = ['status' => $e->getMessage()];
	    }
	    return $result;
	}
	
	 public function event_post(){

        $headers = $this->input->request_headers();
        if(@$headers['Authorization']){
		    $token = $headers['Authorization'];
		    $output = $this->tokenValidate($token);
		    if(@$output['status'] == 'success'){
				$eventname = $this->security->xss_clean($this->input->post("eventname"));
				$eventdesc = $this->security->xss_clean($this->input->post("eventdesc"));
				$eventtime = $this->security->xss_clean($this->input->post("eventtime"));
				$user_id = $this->security->xss_clean($this->input->post("user_id"));
				$this->form_validation->set_rules("user_id", "user id", "required");
				$this->form_validation->set_rules("eventname", "eventname", "required");
				$this->form_validation->set_rules("eventdesc", "eventdesc", "required");
				$this->form_validation->set_rules("eventtime", "eventtime", "required");
				if($this->form_validation->run() === FALSE){
					$this->response(array(
					"status" => 0,
					"message" => strip_tags(validation_errors())
					) , REST_Controller::HTTP_NOT_FOUND);
				}else{
					$create_datetime= date('Y-m-d H:i:s');
					$insert_data =array('event_name'=>$eventname,
										'user_id' =>$user_id,
										'event_description'=>$eventdesc,
										'event_time'=>$eventtime,
										'created_time_stamp'=>$create_datetime);
					$this->db->insert("events", $insert_data);
					$this->response(array(
			        "status" => 1,
			        "message" => "Event inserted"
			      ), REST_Controller::HTTP_OK);
				}

		    }else{
					$this->response(array(
					"status" => 0,
					"message" => "Invalid Token",
					) , REST_Controller::HTTP_NOT_FOUND);
		    }
		}else{
					$this->response(array(
					"status" => 0,
					"message" => "No authorization header Found",
					) , REST_Controller::HTTP_NOT_FOUND);
		}	

    }
	
}