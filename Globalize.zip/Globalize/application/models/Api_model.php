<?php

class Api_model extends CI_Model{

	public function __construct(){
	    parent::__construct();
	}

    public function check_user_exists($username, $password){
 
	    $key = $this->config->item('encryption_key');
	    $hashed = hash('sha512', $key . $password);
	    $hashed_password = hash('sha512', $hashed . $password);
	    $query = $this->db->select('id,username')
	        ->where('username', $username)
	        ->where('password', $hashed_password)
	        ->limit(1)
	        ->get('users'); //echo $this->db->last_query(); exit;
	    $result = $query->row_array();
	    return $result;
	} 
	public function readEvents($uid = NULL){
 
	    $this->db->select('*');
	    $this->db->from('events');
	    $this->db->where('user_id',$uid);
	    $query=$this->db->get();
	    return $query->result_array();
	}  
}

