<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
<?php 
  $this->load->view('user/head');
?>
<body class ="color_blue">


<div class="container" class ="color_container">
<div class="row mt-4">
<form action="#" method="post" id="reg_form" class ="frmwrap">

  <div class ="text-set">
    <h2 class ="text-centre">Registration</h2>
    
    <div class="col-md-12">
    <label for="uname"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="uname" id ="uname" required>
  </div>
    <div class="col-md-12">
    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" id ="password" name="password" required>
  </div>
  <div class="col-md-12">
    <label for="psw"><b>Confirm Password</b></label>
    <input type="password" placeholder="Enter Password" name="confirm" id = "confirm" required>  

    <button type="button" class="btn" id="reg">Register</button>
    <button type="button" class="btn" id="log" onclick="history.back();">Cancel</button>
    </div> 
  </div>
</form>
</div>
</div>

<script src="<?=base_url().'assets/js/registration.js'?>">

 
</script>

</body>
</html>
