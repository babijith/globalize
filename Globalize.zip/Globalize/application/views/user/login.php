<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
<?php 
  $this->load->view('user/head');
?>

<body class="color_blue">

<div class="container" class ="color_container">
<div class="row mt-4">
  <form action="#" id="loginform" name="loginform">

  <div class="text-set">
   <h2 class ="text-centre text-uppercase" text-align-center>Login</h2>
   <p class="text-centre error" id="showmessage"></p>
   <div class="col-md-12">
    <label for="username"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="username" id="username" required>
   </div>
   <div class="col-md-12">
    <label for="password"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" id="password" required>
    <button type="button" id="login" class ="btn">Login</button>
    </div>    
    
	Not registered yet !! click <a href = '<?=base_url(); ?>user/registration'>here</a> to register
  </div>
	</div>    
		
	</div>

</form>
</div>
</div>
<script src="<?=base_url().'assets/js/login.js'?>">

 
</script>
</body>
</html>
