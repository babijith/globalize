<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
<?php 
  $this->load->view('user/head');
?>

<header>
  <div class="overlay">
    <h1>Event Details</h1>
   
  </div>
</header>



<body class="color_blue">
<section >
<div class="container">
   <div class="row mt-4 justify-content-end">
        <div class="  col-md-4 text-right d-flex">          
          <a type="button" class="btn btn-success mx-2" data-toggle="modal" data-target="#exampleModal">Add event</a>
          <a href="<?=base_url().'user/logout';?>" class="btn btn-danger mx-2">Logout</a>
        </div>
   </div>
   <hr>
</div>
<div class="container mt-4" id ="grid">
  <div class="row justify-content-left text-center">
<?php if($events){ 
  foreach ($events as $key => $value) {
  ?>
    <div class="col-md-3 text-white mb-4 mt-3" >
      <div class="bg-primary">
      <div class="card-header">Event: <?=$value['event_name']?></div>
        <div class="card-body">
          <h5 class="card-title font-weight-bold">Date:</h5>
          <p><?=$value['event_time']?></p>
          <p class="card-text">Description: <?=$value['event_description']?></p>
          
       </div>
       </div>
    </div>
<?php }
}else{

  echo "No events Please add any event";
} ?>

  </div>  
</div>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         
         <div class="modal-body p-5">
            <div class="container">
               <div class="row">
                  <form action="#" id="eventsaveform" name="eventsaveform">
                     <div class="container">
                        <h4 class ="text-centre ">Add Event</h4>
                        <p class="text-centre error" id="showmessage"></p>
                        <div class="col-md-12">
                           <label for="EventName"><b>Event name:</b></label>
                           <input type="text" placeholder="Enter event name" name="eventname" id="eventname" required>
                        </div>
                      <div class="col-md-12">
                        <label for="EventDesc"><b>Event Description:</b></label>
                        <input type="text" placeholder="Enter event description" name="eventdesc" id="eventdesc" required>
                      </div>
						<div class="col-md-12">
                           <label for="EventTime"><b>Event Time:</b></label>
						</div>
                        <div class="col-md-12">   
						    <input type="datetime-local" id="eventtime" name="eventtime" required>
                        </div>
						<div class="col-md-12 py-3">
						<button type="button" class="btn btn-primary mr-2" id ="save">Save</button>
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						</div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
</section>

<script src="<?=base_url().'assets/js/event.js'?>">

 
</script>

</body>