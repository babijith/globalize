 $(function() {
    $('#save').on('click',function(){
       $("#eventsaveform").submit();
    })
  });

 $("#eventsaveform").validate({
    rules: {
      eventname: "required",
      eventdesc: "required",
      eventtime: "required"
    },
    messages: {
      eventname: "Please enter your eventname",
      eventdesc: "Please enter event description",
      eventtime: "Please enter event time",
    },
    submitHandler: function(form) {
      var eventname = $('#eventname').val();
      var eventdesc = $('#eventdesc').val();
      var eventtime = $('#eventtime').val();
      $.ajax({
        url: home_url+'user/event',
        type: "POST",
        dataType: "json",
        data:{eventname:eventname,eventdesc:eventdesc,eventtime:eventtime},
        success: function(data){
          if(data.status ==0){
            $('#showmessage').text(data.message);
          }else{
            $('.modal').modal('hide');
            window.location.href= home_url+'user/event';
          }
        }
      });
    }
  });