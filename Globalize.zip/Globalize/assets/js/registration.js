  $(function() {
    $('#reg').on('click',function(){
       $("#reg_form").submit();
    })
  });

 $("#reg_form").validate({
    rules: {
      uname: "required",
      password: {
        required: true,
        minlength: 6
      },
      confirm: {
        required: true,
        minlength: 6,
        equalTo: "#password"
      },
    },
    messages: {
      uname: "Please enter your username",
      password: {
        required: "Please provide a password",
        minlength: "Your password must be at least 6 characters long"
      },
      confirm: {
        required: "Please provide confirm password",
        minlength: "Your password must be at least 6 characters long",
        equalTo: "Password and confirm password should same"
      },
    },
    submitHandler: function(form) {
      var username = $('#uname').val();
      var password = $('#password').val();
      var confirm = $('#confirm').val();
      $.ajax({
        url: home_url+'user/registration',
        type: "POST",
        dataType: "json",
        data:{username:username,password:password,confirm:confirm},
        success: function(data){
          if(data.status ==0){
            $('#showmessage').text(data.message);
          }else{ 
           window.location.href =home_url+'User/';
          }
        }
      });
    }
  });