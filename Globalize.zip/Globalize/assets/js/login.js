  $(function() {
    $('#login').on('click',function(){
       $("#loginform").submit();
    })
  });

 $("#loginform").validate({
    rules: {
      username: "required",
      password: {
        required: true,
        minlength: 6
      }
    },
    messages: {
      username: "Please enter your username",
      password: {
        required: "Please provide a password",
        minlength: "Your password must be at least 6 characters long"
      },
    },
    submitHandler: function(form) {
      var username = $('#username').val();
      var password = $('#password').val();
      $.ajax({
        url: home_url+'user/login',
        type: "POST",
        dataType: "json",
        data:{username:username,password:password},
        success: function(data){
          if(data.status ==0){
            $('#showmessage').text(data.message);
          }else{
            window.location.href= home_url+'user/event';
          }
        }
      });
    }
  });